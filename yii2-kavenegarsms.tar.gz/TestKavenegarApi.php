<?php 
///header('Content-Type:text/plain; charset=utf-8');
namespace moghadam\kavenegarSms;


require("KavenegarApi.php");
class  TestKavenegarApi
{
	private $apiKey;
	public function __construct($apiK = '')
	{
		if($apiK==''){
			$this->apiKey="3043717574742B796D5A613062566650302F31634F413D3D";
		}else{
			$this->apiKey=$apiK;
		}
		$this->api = new KavenegarApi($this->apiKey);
	}

	public function Send($message,$receptor,$sender="10006707323323")
	{
		$out = array(
			"result" => NULL,
			"error" => NULL
		);
		try{
			$result = $this->api->Send($receptor,$sender,$message);
			$out['result'] = $result;
		}
		catch(ApiException $e){
			$out['error'] = $e->errorMessage();
		}
		catch(HttpException $e){
			$out['error'] = $e->errorMessage();
		}
		return $out;
	}	
}	

?>
