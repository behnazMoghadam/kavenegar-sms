<?php
abstract class ApiLogs extends General {
    const  Justforfault  = "justforfault";
    const  Enabled = "enabled";
    const  Disabled = "disabled";
}
?>