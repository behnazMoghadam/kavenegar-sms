<?php
abstract class General {
	const  Enabled = "enabled";
    const  Disabled = "disabled";
}
?>